# SSH Key Configuration

Place the SSH private key (.pem) file for the database connection in this directory.

Expected filename: db.pem
